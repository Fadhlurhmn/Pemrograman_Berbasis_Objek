﻿**LAPORAN JOBSHEET 3**

**PRAKTIKUM PEMROGRAMAN OOP**



![Politeknik Negeri Malang (POLINEMA)](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.001.png)

**Disusun Oleh:**

Fadhlurohman Al Farabi

TI-2C

NIM. 2241720081





**PROGRAM STUDI D-IV TEKNIK INFORMATIKA**

**JURUSAN TEKNOLOGI INFORMASI**

**POLITEKNIK NEGERI MALANG**

**2023**








Enkapsulasi Pada Pemrograman Berorientasi Objek

# <a name="1._kompetensi"></a>1. Kompetensi

Setelah melakukan percobaan pada modul ini, mahasiswa memahami konsep:

1. Konstruktor
1. Akses Modifier
1. Atribut/method pada class
1. Intansiasi atribut/method
1. Setter dan getter
1. Memahami notasi pada UML Class Diagram


2. # <a name="2._pendahuluan"></a>Pendahuluan

Pada pertemuan pertama dan kedua telah dibahasan konsep dasar dari pemrograman berbasis objek (PBO), perbedaan antara pemrograman berbasis objek dengan pemrograman struktural, dan telah dibahas konsep class dan object pada PBO. Selanjutnya pada modul ini akan dibahas konsep enkapsulasi pada PBO dan notasi yang ada pada UML Class diagram.
1. ## <a name="2.1_enkapsulasi"></a>Enkapsulasi

Pada modul pertama telah dijabarkan definisi dari enkapsulasi sebagai berikut:

Enkapsukasi disebut juga dengan **information-hiding**. Dalam berinteraksi dengan objek, seringkali kita tidak perlu mengetahui kompleksitas yang ada didalamnya. Hal ini akan lebih mudah dipahami jika kita membayangkan atau menganalisa objek yang ada disekitar kita, misalnya objek sepeda, ketika kita mengganti gear pada sepeda, kita tinggal menekan tuas gear yang ada di grip setang sepeda saja. Kita tidak perlu mengetahui bagaimana cara gear berpindah secara teknis. Contoh objek lain misalnya mesin penghisap debu (vacum cleaner), ketika kita mencolokkan kabel vacum cleaner dan menyalakan sakelarnya maka mesin tersebut siap digunakan untuk menghisap debu. Dalam proses tersebut kita tidak mengetahui proses rumit yang terjadi ketika mengubah listrik menjadi tenaga dari vacum cleaner. Dalam contoh diatas vacum cleaner dan sepeda telah menerapkan enkapsulasi atau disebut juga **information-hiding atau data hiding** karena menyembunyikan detail proses suatu objek dari pengguna.
1. ## <a name="2.2_konstruktor"></a>Konstruktor

Konstruktor mirip dengan method cara deklarasinya akan tetapi tidak memiliki tipe return. Dan konstruktor dieksekusi ketika instan dari objek dibuat. Jadi setiap kali sebuat objek dibuat dengan keyword new() maka konstruktor akan dieksekusi. Cara untuk membuat konstruktor adalah sebagai berikut:

1. Nama konstruktor harus sama dengan nama class
1. Konstruktor tidak memiliki tipe data return
1. Konstruktor tidak boleh menggunakan modifier abstract, static, final, dan syncronized

Note: Di java kita dapat memiliki konstruktor dengan modifier private, protected, public or default.
1. ## <a name="2.3_akses_modifier"></a>Akses Modifier

Terdapat 2 tipe modifier di java yaitu : akses modifier dan non-access modifier. Dalam hal ini kita akan fokus pada akses modifier yang berguna untuk mengatur akses method, class, dan constructor. Terdapat 4 akses modifier yaitu:

1. private – hanya dapat diakses di dalam kelas yang sama
1. default – hanya dapat diakses di dalam package yang sama
1. protected – dapat diakases di luar package menggunakan subclass (membuat inheritance)
1. public – dapat diakases dari mana saja Detail akses modifier dapat dilihat pada Tabel 1.1.

**Tabel 1. 1 Detail Access Modifier**


|**Access Modifier**|**within class**|**within package**|**outside package by subclass only**|**outside package**|
| :- | :- | :- | :- | :- |
|<p></p><p>**Private**</p>|<p></p><p>Y</p>|<p></p><p>N</p>|<p></p><p>N</p>|<p></p><p>N</p>|
|<p></p><p>**Default**</p>|<p></p><p>Y</p>|<p></p><p>Y</p>|<p></p><p>N</p>|<p></p><p>N</p>|
|<p></p><p>**Protected**</p>|<p></p><p>Y</p>|<p></p><p>Y</p>|<p></p><p>Y</p>|<p></p><p>N</p>|
|<p></p><p>**Public**</p>|<p></p><p>Y</p>|<p></p><p>Y</p>|<p></p><p>Y</p>|<p></p><p>Y</p>|

1. ## <a name="2.4_getter__dan_setter"></a>Getter dan Setter

Getter adalah public method dan memiliki tipe data return, yang berfungsi untuk mendapatkan nilai dari atribut private. Sedangkan setter adalah public method yang tidak memliki tipe data return, yang berfungsi untuk memanipulasi nilai dari atribut private.
1. ## <a name="2.5_notasi_uml_class_diagram"></a>Notasi UML Class Diagram

Secara umum bentuk UML class diagram adalah seperti pada Gambar ..

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.002.png)

**Gambar 1. 1 UML Class Diagram**

Keterangan :

1. Class
1. Interface
1. Enumeration – adalah tipe data yang memiliki nilai atau literal yang terbatas.
1. Atrributes
1. Method
1. Literals

Notasi akses modifier pada UML class diagram adalah sebagai berikut:

1. Tanda plus (+) untuk public
1. Tanda pagar (#) untuk protected
1. Tanda minus (-) untuk private
1. Untuk default, maka tidak diberi notasi
3. # <a name="3._percobaan"></a>Percobaan
   1. ## <a name="3.1_percobaan_1_-_enkapsulasi"></a>Percobaan 1 - Enkapsulasi
Didalam percobaan enkapsulasi, buatlah class Motor yang memiliki atribut kecepatan dan kontakOn, dan memiliki method printStatus() untuk menampilkan status motor. Seperti berikut

1. Buka Netbeans, buat project **MotorEncapsulation**.
1. Buat class **Motor**. Klik kanan pada package **motorencapsulation** – New – Java Class.
1. Ketikkan kode class Motor dibawah ini.

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.003.png)

bentuk UML class diagram class Motor adalah sebagai berikut:

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.004.png)

1. Kemudian buat class MotorDemo, ketikkan kode berikut ini.

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.005.png)

1. Hasilnya adalah sebagai berikut:

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.006.png)


Dari percobaan 1 - enkapsulasi, menurut anda, adakah yang janggal?

Yaitu, kecepatan motor tiba-tiba saja berubah dari 0 ke 50. Lebih janggal lagi, posisi kontak motor masih dalam kondisi OFF. Bagaimana mungkin sebuah motor bisa sekejap berkecepatan dari nol ke 50, dan itupun kunci kontaknya OFF?

Nah dalam hal ini, akses ke atribut motor ternyata tidak terkontrol. Padahal, objek di dunia nyata selalu memiliki batasan dan mekanisme bagaimana objek tersebut dapat digunakan. Lalu, bagaimana kita bisa memperbaiki class Motor diatas agar dapat digunakan dengan baik? Kita bisa pertimbangkan beberapa hal berikut ini:

1. Menyembunyikan atribut internal (kecepatan, kontakOn) dari pengguna (class lain)  

1. Menyediakan method khusus untuk mengakses atribut.  

Untuk itu mari kita lanjutkan percobaan berikutknya tentang Access Modifier.


1. ## <a name="3.2_percobaan_2_-_access_modifier"></a>Percobaan 2 - Access Modifier
Pada percobaan ini akan digunakan access modifier untuk memperbaiki cara kerja class Motor pada percobaan ke-1.

1. Ubah cara kerja class motor sesuai dengan UML class diagram berikut.

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.007.png)

1. Berdasarkan UML class diagram tersebut maka class Motor terdapat perubahan, yaitu:

1. Ubah access modifier kecepatan dan kontakOn menjadi private
1. Tambahkan method nyalakanMesin, matikanMesin, tambahKecepatan, kurangiKecepatan.

Implementasi class Motor adalah sebagai berikut:

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.008.png)

1. Kemudian pada class MotorDemo, ubah code menjadi seperti berikut:

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.009.png)

1. Hasilnya dari class MotorDemo adalah sebagai berikut:

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.010.png)

Dari percobaan diatas, dapat kita amati sekarang atribut kecepatan tidak bisa diakses oleh pengguna dan diganti nilainya secara sembarangan. Bahkan ketika mencoba menambah kecepatan saat posisi kontak masih OFF, maka akan muncul notifikasi bahwa mesin OFF. Untuk mendapatkan kecepatan

yang diinginkan, maka harus dilakukan secara gradual, yaitu dengan memanggil method tambahKecepatan() beberapa kali. Hal ini mirip seperti saat kita mengendarai motor.
1. ## <a name="3.3_pertanyaan"></a>Pertanyaan
   1. Pada class TestMobil, saat kita menambah kecepatan untuk pertama kalinya, mengapa

muncul peringatan “Kecepatan tidak bisa bertambah karena Mesin Off!”?  

Jawab : Dikarenakan Kontak atau mesin masih Off. Perhatikan kode program berikut

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.011.png)

Pada waktu pertama kali mendeklarasikan variable kontakOn adalah bernilai false atau bisa diartikan mesin dalam kondisi mati. Lalu, pada method tambahKecepatan() memiliki sebuah kondisi bila mesin mati maka akan muncul sebuah peringatan sesuai dengan kode program dibawah ini.

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.012.png)

1. Mengapa atribut kecepatan dan kontakOn diset private?  

Jawab : Untuk menyembunyikan nilai dari variable kontakOn. Sehingga ketika ingin menambahkan kecepatan maka nilai dari variable kontakOn harus bernilai true atau menggunakan method nyalakanMesin(). 

1. Ubah class Motor sehingga kecepatan maksimalnya adalah 100!

Jawab : Untuk membatasi kecepatan maksimal. Kita bisa menambahkan sebuah kondisi pada method tambahKecepatan(). Ketika memanggil method tersebut akan ada pengecekan apakah kecepatan lebih dari 100 atau tidak. Jika, tidak maka kecepatan bisa ditambahkan. Untuk lebih jelasnya perhatikan kode program dibawah ini

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.013.png)



1. ## <a name="3.4_percobaan_3_-__getter_dan_setter"></a>Percobaan 3 - Getter dan Setter
Misalkan di sebuah sistem informasi koperasi, terdapat class Anggota. Anggota memiliki atribut nama, alamat dan simpanan, dan method setter, getter dan setor dan pinjam. Semua atribut pada anggota tidak boleh diubah sembarangan, melainkan hanya dapat diubah melalui method setter, getter, setor dan tarik. Khusus untuk atribut simpanan tidak terdapat setter karena simpanan akan bertambah ketika melakukan transaksi setor dan akan berkurang ketika melakukan peminjaman/tarik.

1. Berikut ini UML class buatlah class Mahasiswa pada program:

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.014.png)

1. Sama dengan percobaan 1 untuk membuat project baru
   1. Buka Netbeans, buat project **KoperasiGetterSetter**.
   1. Buat class **Anggota**. Klik kanan pada package **koperasigettersetter** – New – Java Class.
   1. Ketikkan kode class Anggota dibawah ini.

![Anggota.java - PERTEMUAN 3 - Visual Studio Code](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.015.png)

Jika diperhatikan pada class Anggota, atribut nama dan alamat memili masing-masing 1 getter dan setter. Sedangkan atribut simpanan hanya memiliki getSimpanan() saja, karena seperti tujuan awal, atribut simpanan akan berubah nilainya jika melakukan transaksi setor() dan pinjam/tarik().

1. Selanjutnya buatlah class KoperasiDemo untuk mencoba class Anggota.

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.016.png)

1. Hasil dari main method pada langkah ketiga adalah

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.017.png)

Dapat dilihat pada hasil percobaan diatas, untuk mengubah simpanan tidak dilakukan secara langsung dengan mengubah atribut simpanan, melainkan melalui method setor() dan pinjam(). Untuk menampilkan nama pun harus melalui method getNama(), dan untuk menampilkan simpanan melalui getSimpanan().
1. ## <a name="3.5_percobaan_4_-__konstruktor,_instansi"></a>Percobaan 4 - Konstruktor, Instansiasi
   1. Langkah pertama percobaan 4 adalah ubah class KoperasiDemo seperti berikut

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.018.png)

1. Hasil dari program tersebut adalah sebagai berikut

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.019.png)

Dapat dilihat hasil running program, ketika dilakukan pemanggilan method getNama() hasilnya hal ini terjadi karena atribut nama belum diset nilai defaultnya. Hal ini dapat ditangani dengan membuat kontruktor.

1. Ubah class Anggota menjadi seperti berikut

![Anggota.java - PERTEMUAN 3 - Visual Studio Code](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.020.png)

Pada class Anggota dibuat kontruktor dengan access modifier default yang memiliki 2 parameter nama dan alamat. Dan didalam konstruktor tersebut dipastikan nilai simpanan untuk pertama kali adalah Rp. 0.

1. Selanjutnya ubah class KoperasiDemo sebagai berikut

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.021.png)

1. Hasil dari program tersebut adalah sebagai berikut

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.022.png)

Setelah menambah konstruktor pada class Anggoata maka atribut nama dan alamat secara otomatis harus diset terlebih dahulu dengan melakukan passing parameter jika melakukan instansiasi class Anggota. Hal ini biasa dilakukan untuk atribut yang membutuhkan nilai yang spesifik. Jika tidak membutuhkan nilai spesifik dalam konstruktor tidak perlu parameter. Contohnya simpanan untuk anggota baru diset 0, maka simpanan tidak perlu untuk dijadikan parameter pada konstruktor.

3\.6 Pertanyaan – Percobaan 3 dan 4

1\. Apa yang dimaksud getter dan setter?

`    `Jawab : Method *setter* dipergunakan untuk melakukan pemberian nilai dari sebuah attribute class. Sedangkan method *getter* dipergunakan untuk memberikan nilai attribute dari sebuah class.

2\. Apa kegunaan dari method getSimpanan()?

`    `Jawab : Method getSimpanan() dipergunakan untuk mengembalikan nilai dari attribut simpanan yang berada di class Anggota. 

3\. Method apa yang digunakan untk menambah saldo?

`     `Jawab : Metod untuk menambah saldo peminjaamn adalah pinjam(). 

4\. Apa yand dimaksud konstruktor?

`    `Jawab : konstruktor adalah method khusus yang dieksekusi secara otomatis saat objek pertama kali dibuat. 

5\. Sebutkan aturan dalam membuat konstruktor?

`    `Jawab : aturan dalam membuat konstruktor adalah 

`	`- nama konstruktor harus sama dengan nama class

`	`- konstruktor tidak boleh memiliki nilai pengembalian atau return

`	`- konstruktor dapat memiliki parameter atau tidak

`	`- jika kelas tidak memiliki konstruktor, maka java akan membuatkan konstruktor default secara otomatis

6\. Apakah boleh konstruktor bertipe private?

`    `Jawab : konstruktor dapat dideklarasikan sebagai private. Namun, konstruktor tersebut hanya dapat diakses dari dalam class itu sendiri.

7\. Kapan menggunakan parameter dengan passsing parameter?

`    `Jawab : terdapat dua cara mengirimkan parameter ke fungsi. Yaitu, passing by value dan passing by reference. Passing by value digunakan ketika ingin mengirimkan nilai primitif seperti int, float, double, boolean ke dalam fungsi. Sedangkan passing by reference digunakan ketika ingin mengirimkan objek atau array ke dalam fungsi.

8\. Apa perbedaan atribut class dan instansiasi atribut?

`    `Jawab : attribut class adalah attribut yang didefiniskan pada class dan bersifat statis, artinya nilai dari atribut ini sama untuk semua objek yang dibuat dari class tersebut. Sedangkat instansiasi attribut adalah attribut yang didefinisikan pada level objek yang bersifat dinamis, artinya nilai dari attribut dapat berbeda-beda untuk setiap objek.

9\. Apa perbedaan class method dan instansiasi method?

`    `Jawab : class method adalah method yang didefinisikan pada level kelas dan dapat dipanggil tanpa membuat objek dari class tersebut. Sedangkan instansiasi method adalah method yang didefinisikan pada level objek dan hanya dapat dipanggil setelah objek dari kelas tersebut dibuat.















4. # Tugas
   1. Cobalah program dibawah ini dan tuliskan hasil outputnya

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.023.png) ![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.024.png)

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.025.png)

1. Pada program diatas, pada class EncapTest kita mengeset age dengan nilai 35, namun pada saat ditampilkan ke layar nilainya 30, jelaskan mengapa.

Dikarenakan pada method setAge() terdapat sebuah kondisi jika argumen yang diinput lebih dari 30, maka variable age akan di set bernilai 30. Untuk lebih jelasnya perhatikan program dibawah ini. 

Jawaban:

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.026.png)![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.027.png)

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.028.png)










1. Ubah program diatas agar atribut age dapat diberi nilai maksimal 30 dan minimal 18.

Jawaban : 

Untuk membuat persyaratan seperti di soal maka diperlukan kondisi pada if seperti pada program dibawah.

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.029.png)

Dimana ketika user menginput umur yang lebih dari 30 ataupun dibawah 18, maka akan ada pesan erorr yang ditampilkan sehingga inputan data tidak akan diproses.

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.030.png)

Hasil running

`	  `![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.031.png)

1. Pada sebuah sistem informasi koperasi simpan pinjam, terdapat class Anggota yang memiliki atribut antara lain nomor KTP, nama, limit peminjaman, dan jumlah pinjaman. Anggota dapat meminjam uang dengan batas limit peminjaman yang ditentukan. Anggota juga dapat mengangsur pinjaman. Ketika Anggota tersebut mengangsur pinjaman, maka jumlah pinjaman akan berkurang sesuai dengan nominal yang diangsur. Buatlah class Anggota tersebut, berikan atribut, method dan konstruktor sesuai dengan kebutuhan. Uji dengan TestKoperasi berikut ini untuk memeriksa apakah class Anggota yang anda buat telah sesuai dengan yang diharapkan.

public class TestKoperasi

{

public static void main(String[] args)

{

Anggota donny = new Anggota("111333444", "Donny", 5000000);

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.032.png)

System.out.println("Nama Anggota: " + donny.getNama()); System.out.println("Limit Pinjaman: " + donny.getLimitPinjaman());

System.out.println("\nMeminjam uang 10.000.000..."); donny.pinjam(10000000);

System.out.println("Jumlah pinjaman saat ini: " + donny.getJumlahPinjaman());

System.out.println("\nMeminjam uang 4.000.000..."); donny.pinjam(4000000);

System.out.println("Jumlah pinjaman saat ini: " + donny.getJumlahPinjaman());

System.out.println("\nMembayar angsuran 1.000.000"); donny.angsur(1000000);

System.out.println("Jumlah pinjaman saat ini: " + donny.getJumlahPinjaman());

System.out.println("\nMembayar angsuran 3.000.000"); donny.angsur(3000000);

System.out.println("Jumlah pinjaman saat ini: " + donny.getJumlahPinjaman());

}

}
![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.033.png)

Hasil yang diharapkan:

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.034.png)





















`	`Jawaban : 

`	`Source Code

Class Anggota

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.035.png)












Class TestKoperasi

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.036.png)

Output

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.037.png)











1. Modifikasi soal no. 4 agar nominal yang dapat diangsur minimal adalah 10% dari jumlah pinjaman saat ini. Jika mengangsur kurang dari itu, maka muncul peringatan “Maaf, angsuran harus 10% dari jumlah pinjaman”.

Jawaban : 

Source Code

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.038.png)


`	`Output

`	`![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.039.png)

1. Modifikasi class TestKoperasi, agar jumlah pinjaman dan angsuran dapat menerima input dari console.

Jawaban : 

Source Code

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.040.png)













Output

![](Aspose.Words.bd4334b2-62b9-4676-95a3-822ff229be98.041.png)


