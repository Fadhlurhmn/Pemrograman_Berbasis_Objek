﻿**LAPORAN JOBSHEET 2**

**PRAKTIKUM PEMROGRAMAN OOP**



![Politeknik Negeri Malang (POLINEMA)](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.001.png)

**Disusun Oleh:**

Fadhlurohman Al Farabi

TI-2C

NIM. 2241720081










**PROGRAM STUDI D-IV TEKNIK INFORMATIKA**

**JURUSAN TEKNOLOGI INFORMASI**

**POLITEKNIK NEGERI MALANG**

**2023**



1. # **Percobaan**
   1. **Percobaan 1: Membuat Class Diagram**

Studi Kasus 1:

Dalam suatu perusahaan salah satu data yang diolah adalah data karyawan. Setiap karyawan memiliki id, nama, jenis kelamin, jabatan, jabatan, dan gaji. Setiap mahasiswa juga bisa menampilkan data diri pribadi dan melihat gajinya.

1. Gambarkan desain class diagram dari studi kasus 1!,

![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.002.png)

1. Sebutkan Class apa saja yang bisa dibuat dari studi kasus 1!,

Jawab : Class yang tersedia ada dua, yaitu class Karyawan dan class Mahasiswa.

1. Sebutkan atribut beserta tipe datanya yang dapat diidentifikasi dari masing-masing class dari studi kasus 1!

Attribut Class Karyawan : 

\- id, nama, jenisKelamin, jabatan : memiliki tipe data String

\- gajiKaryawan : memiliki tipe data double

Attribut Class Mahasiswa : 

\- nama, alamat, nim, jenisKelamin : String

1. Sebutkan method-method yang sudah anda buat dari masing-masing class pada studi kasus 1!

Method Class Karyawan : 

\- tampilBiodata() : void

\- melihatGaji() : void

Method Class Mahasiswa : 

\- tampilBiodata() : void

































1. # **Percobaan 2: Membuat dan mengakses anggota suatu class**
Studi Kasus 2:

Perhatikan class diagram dibawah ini. Buatlah program berdasarkan class diagram tersebut!  

![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.003.jpeg)

Langkah kerja:

1. Bukalah text editor atau IDE, misalnya Notepad ++ / netbeans.
1. Ketikkan kode program berikut ini:

![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.004.png)

1. Simpan dengan nama file Mahasiswa.java.
1. Untuk dapat mengakses anggota-anggota dari suatu obyek, maka harus dibuat instance dari class tersebut terlebih dahulu. Berikut ini adalah cara pengaksesan anggota- anggota dari class Mahasiswa dengan membuka file baru kemudian ketikkan kode program berikut:

![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.005.png)

1. Simpan file dengan TestMahasiswa.java
1. Jalankan class TestMahasiswa

![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.006.png)

1. Jelaskan pada bagian mana proses pendeklarasian atribut pada program diatas!

Jawab : Pendeklarasian attribut terdapat pada Class Mahasiswa yang tertera pada gambar dibawah ini.

![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.007.png)

1. Jelaskan pada bagian mana proses pendeklarasian method pada program diatas!

Jawab : Pendeklarasian method terdapat pada Class Mahasiswa yang tertera pada gambar dibawah ini.

`	`![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.008.png)

1. Berapa banyak objek yang di instansiasi pada program diatas!

Jawab : Objek yang di instansiasi hanya ada sastu yaitu objek mhs1.

1. Apakah yang sebenarnya dilakukan pada sintaks program “mhs1.nim=101” ?

Jawab : Proses tersebut adalah kita memberikan value kepada attribut nim pada objek mhs1.

1. Apakah yang sebenarnya dilakukan pada sintaks program “mhs1.tampilBiodata()” ?

Jawab : Proses tersebut adalah kita memanggil method tampilBiodata pada objek mhs1.


1. Instansiasi 2 objek lagi pada program diatas!

![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.009.png)






1. # **Percobaan 3: Menulis method yang memiliki argument/parameter dan memiliki return**
Langkah kerja:

1. Bukalah text editor atau IDE, misalnya Notepad ++ / netbeans.
1. Ketikkan kode program berikut ini:

![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.010.png)

1. Simpan dengan nama file Barang.java
1. Untuk dapat mengakses anggota-anggota dari suatu obyek, maka harus dibuat instance dari class tersebut terlebih dahulu. Berikut ini adalah cara pengaksesan anggota- anggota dari class Barang dengan membuka file baru kemudian ketikkan kode program berikut:

![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.011.png)

1. Simpan dengan nama file TestBarang.java
1. Jalankan program tersebut!

![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.012.png)

1. Apakah fungsi argumen dalam suatu method?

Jawab : Fungsi argument dalam sebuah method adalah digunakan untuk inputan data. Jadi, semua method yang memerlukan sebuah data inputan untuk memproses sesuatu maka akan dipermudah dengan menggunakan argument.

1. Ambil kesimpulan tentang kegunaan dari kata kunci return , dan kapan suatu method harus memiliki return!

Jawab : Penggunaan return adalah mengembalikan nilai dari hasil suatu method. Jadi, Ketika menggunakan tipe selain void pada method akan diperlukan return untuk mengembalikan nilainya. Sehingga Ketika dipanggil method tersebut diperlukan sebuah variable untuk menampung nilai atau value dari hasil return tersebut















1. # **Tugas**
   1. Suatu toko persewaan video game salah satu yang diolah adalah peminjaman, dimana data yang dicatat ketika ada orang yang melakukan peminjaman adalah id, nama member, nama game, dan harga yang harus dibayar. Setiap peminjaman bisa menampilkan data hasil peminjaman dan harga yang harus dibayar. Buatlah class diagram pada studi kasus diatas!

Penjelasan:

0. Harga yang harus dibayar diperoleh dari lama sewa x harga.
0. Diasumsikan 1x transaksi peminjaman game yang dipinjam hanya 1 game saja.

1. Buatlah program dari class diagram yang sudah anda buat di no 1!

![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.013.png)

1. Buatlah program sesuai dengan class diagram berikut ini:

![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.014.jpeg)

Source Code

![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.015.png)

Output

`	 `![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.016.png)

1. Buatlah program sesuai dengan class diagram berikut ini:

![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.017.jpeg)

Deskripsi / Penjelasan :

0. Nilai atribut hargaDasar dalam Rupiah dan atribut diskon dalam %
0. Method hitungHargaJual() digunakan untuk menghitung harga jual dengan perhitungan berikut ini:
# **harga jual = harga dasar – (diskon x harga dasar)**

0. Method tampilData() digunakan untuk menampilkan nilai dari kode, namaBarang, hargaDasar, diskon dan harga jual.

Source Code

![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.018.png)

Output

![](Aspose.Words.15bb96ca-3c64-4b69-8359-72454303f961.019.png)
